import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  console.error('تنبيه: متغيرات الاتصال بقاعدة بيانات Supabase غير مضبوطة في ملف .env');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
    storageKey: 'alraseem-sudani-auth-session'
  }
});

export const STORAGE_BUCKET = 'artworks';

// التحقق الأمني من الملفات المرفوعة (صور أو تسجيلات صوتية)
const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const MAX_IMAGE_SIZE_BYTES = 10 * 1024 * 1024; // 10MB

const ALLOWED_AUDIO_TYPES = ['audio/webm', 'audio/ogg', 'audio/mp4', 'audio/mpeg', 'audio/wav'];
const MAX_AUDIO_SIZE_BYTES = 5 * 1024 * 1024; // 5MB

export async function uploadArtworkFile(file, userId, folder = 'paintings') {
  if (!userId) throw new Error('يجب تسجيل الدخول لرفع الملفات');
  if (!file) throw new Error('لم يتم اختيار أي ملف');

  if (!ALLOWED_IMAGE_TYPES.includes(file.type)) {
    throw new Error('صيغة الصورة غير مدعومة. الصيغ المسموحة: JPG, PNG, WEBP, GIF');
  }
  if (file.size > MAX_IMAGE_SIZE_BYTES) {
    throw new Error('حجم الصورة يتجاوز الحد المسموح به (10 ميجابايت)');
  }

  const ext = file.name.split('.').pop()?.toLowerCase() || 'jpg';
  const safeExt = ['jpg', 'jpeg', 'png', 'webp', 'gif'].includes(ext) ? ext : 'jpg';
  const fileName = `${userId}/${folder}/${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${safeExt}`;

  const { error: uploadError } = await supabase.storage
    .from(STORAGE_BUCKET)
    .upload(fileName, file, {
      cacheControl: '3600',
      upsert: false,
      contentType: file.type
    });

  if (uploadError) throw uploadError;

  const { data } = supabase.storage.from(STORAGE_BUCKET).getPublicUrl(fileName);
  return data.publicUrl;
}

export async function uploadVoiceComment(blob, userId) {
  if (!userId) throw new Error('يجب تسجيل الدخول لإرسال تعليق صوتي');
  if (!blob) throw new Error('التسجيل الصوتي فارغ');

  const mimeBase = (blob.type || 'audio/webm').split(';')[0];
  if (!ALLOWED_AUDIO_TYPES.includes(mimeBase)) {
    throw new Error('صيغة الصوت غير مدعومة');
  }
  if (blob.size > MAX_AUDIO_SIZE_BYTES) {
    throw new Error('مدة أو حجم التسجيل الصوتي يتجاوز الحد المسموح (5 ميجابايت)');
  }

  const ext = mimeBase.includes('mp4') ? 'm4a' : mimeBase.includes('ogg') ? 'ogg' : 'webm';
  const fileName = `${userId}/voice_comments/${Date.now()}_${Math.random().toString(36).substring(2, 8)}.${ext}`;

  const { error: uploadError } = await supabase.storage
    .from(STORAGE_BUCKET)
    .upload(fileName, blob, {
      cacheControl: '3600',
      upsert: false,
      contentType: mimeBase
    });

  if (uploadError) throw uploadError;

  const { data } = supabase.storage.from(STORAGE_BUCKET).getPublicUrl(fileName);
  return data.publicUrl;
}
