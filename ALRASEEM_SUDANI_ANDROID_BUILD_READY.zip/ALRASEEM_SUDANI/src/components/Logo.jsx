import React from 'react';

export default function Logo({ size = 'md' }) {
  const iconSize = size === 'sm' ? 30 : size === 'lg' ? 48 : 38;
  return (
    <div className="brand-logo" aria-label="الرسيم السوداني">
      <div className="brand-emblem" style={{ width: iconSize, height: iconSize }}>
        <svg viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
          <rect x="3" y="3" width="58" height="58" rx="14" stroke="#D4AF37" strokeWidth="2.5" fill="#141418" />
          {/* زخرفة هندسية مستوحاة من التراث النوبي والخرطوم */}
          <path d="M32 11L49 28L32 45L15 28L32 11Z" stroke="#D4AF37" strokeWidth="2" fill="rgba(212,175,55,0.08)" />
          {/* ريشة رسم ذهبية */}
          <path
            d="M22 48C25 41 31 32 43 20C45 18 47 20 45 22C33 34 25 42 22 48Z"
            fill="#D4AF37"
          />
          <circle cx="32" cy="28" r="3" fill="#F3E5AB" />
        </svg>
      </div>
      <div className="brand-text">
        <span className="brand-ar">الرسيم السوداني</span>
        <span className="brand-en">ALRASEEM SUDANI</span>
      </div>
    </div>
  );
}
