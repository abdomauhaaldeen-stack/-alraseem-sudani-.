import React from 'react';
import { X, User, Calendar } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function LightboxModal({ artwork, onClose }) {
  if (!artwork) return null;

  const artistName =
    artwork.artist_name ||
    artwork.profiles?.artist_name ||
    artwork.profiles?.full_name ||
    'فنان سوداني';

  return (
    <div className="lightbox-backdrop" onClick={onClose}>
      <div className="lightbox-content" onClick={(e) => e.stopPropagation()}>
        <button type="button" className="lightbox-close" onClick={onClose} aria-label="إغلاق">
          <X size={24} />
        </button>

        <div className="lightbox-image-wrap">
          <img src={artwork.image_url} alt={artwork.title} />
        </div>

        <div className="lightbox-info">
          <div>
            <h3>{artwork.title}</h3>
            <p className="text-muted">{artwork.description || 'عمل فني أصيل على منصة الرسيم السوداني'}</p>
          </div>
          <div className="lightbox-actions">
            <Link to={`/artist/${artwork.user_id}`} onClick={onClose} className="btn btn-outline btn-sm">
              <User size={15} />
              <span>{artistName}</span>
            </Link>
            <span className="text-xs text-muted flex-center gap-1">
              <Calendar size={14} />
              {new Date(artwork.created_at).toLocaleDateString('ar-SD')}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
