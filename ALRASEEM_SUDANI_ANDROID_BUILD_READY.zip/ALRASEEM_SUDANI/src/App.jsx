import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HomePage from './pages/HomePage';
import ExplorePage from './pages/ExplorePage';
import ArtworkDetailPage from './pages/ArtworkDetailPage';
import PublishArtworkPage from './pages/PublishArtworkPage';
import ArtistProfilePage from './pages/ArtistProfilePage';
import ArtistsListPage from './pages/ArtistsListPage';
import ContestsPage from './pages/ContestsPage';
import ExhibitionsPage from './pages/ExhibitionsPage';
import FavoritesPage from './pages/FavoritesPage';
import NotificationsPage from './pages/NotificationsPage';
import AuthPage from './pages/AuthPage';
import AdminDashboard from './pages/admin/AdminDashboard';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <div className="app-shell">
          <Navbar />
          <main className="main-content">
            <Routes>
              <Route path="/" element={<HomePage />} />
              <Route path="/explore" element={<ExplorePage />} />
              <Route path="/artwork/:id" element={<ArtworkDetailPage />} />
              <Route path="/publish" element={<PublishArtworkPage />} />
              <Route path="/artist/:id" element={<ArtistProfilePage />} />
              <Route path="/artists" element={<ArtistsListPage />} />
              <Route path="/contests" element={<ContestsPage />} />
              <Route path="/exhibitions" element={<ExhibitionsPage />} />
              <Route path="/favorites" element={<FavoritesPage />} />
              <Route path="/notifications" element={<NotificationsPage />} />
              <Route path="/auth" element={<AuthPage />} />
              <Route path="/admin" element={<AdminDashboard />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </BrowserRouter>
    </AuthProvider>
  );
}
