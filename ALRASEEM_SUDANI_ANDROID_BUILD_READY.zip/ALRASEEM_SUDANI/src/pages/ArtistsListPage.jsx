import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, MapPin } from 'lucide-react';
import { supabase } from '../supabase';

export default function ArtistsListPage() {
  const [artists, setArtists] = useState([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadArtists();
  }, []);

  const loadArtists = async () => {
    setLoading(true);
    const { data } = await supabase
      .from('profiles')
      .select('*')
      .order('is_featured', { ascending: false })
      .order('created_at', { ascending: false });
    setArtists(data || []);
    setLoading(false);
  };

  const filtered = artists.filter((a) => {
    const q = search.toLowerCase();
    return (
      (a.artist_name || '').toLowerCase().includes(q) ||
      (a.full_name || '').toLowerCase().includes(q) ||
      (a.specialty || '').toLowerCase().includes(q) ||
      (a.city || '').toLowerCase().includes(q)
    );
  });

  return (
    <div className="container page-wrapper">
      <div className="page-header">
        <h1>دليل الرسامين والفنانين التشكيليين</h1>
        <p className="text-muted">تعرّف على المبدعين السودانيين وتابع أعمالهم الفنية</p>
      </div>

      <div className="search-bar-inline max-w-md mb-4">
        <Search size={18} />
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="ابحث باسم الفنان أو المدينة أو التخصص..."
        />
      </div>

      {loading ? (
        <p>جاري تحميل قائمة الفنانين...</p>
      ) : filtered.length === 0 ? (
        <div className="empty-state-box">لا يوجد فنانون مطابقون لبحثك.</div>
      ) : (
        <div className="artists-grid">
          {filtered.map((artist) => (
            <Link key={artist.id} to={`/artist/${artist.id}`} className="artist-card">
              {artist.avatar_url ? (
                <img src={artist.avatar_url} alt={artist.artist_name} className="artist-avatar-lg" />
              ) : (
                <div className="artist-avatar-lg avatar-fallback">
                  {(artist.artist_name || artist.full_name || 'ف')[0]}
                </div>
              )}
              <h3>{artist.artist_name || artist.full_name || 'فنان سوداني'}</h3>
              <span className="artist-specialty">{artist.specialty || 'فنان تشكيلي'}</span>
              {artist.city && (
                <span className="text-xs text-muted flex-center gap-1 mt-1">
                  <MapPin size={13} /> {artist.city}
                </span>
              )}
              <p className="artist-bio-snippet">
                {artist.bio || 'عضو في منصة الرسيم السوداني.'}
              </p>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
