import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Mail, Lock, User, KeyRound } from 'lucide-react';
import { supabase } from '../supabase';
import { useAuth } from '../context/AuthContext';
import Logo from '../components/Logo';

export default function AuthPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const [mode, setMode] = useState(searchParams.get('mode') === 'register' ? 'register' : 'login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [artistName, setArtistName] = useState('');
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (user) navigate('/');
  }, [user, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErrorMsg('');
    setMessage('');
    setLoading(true);

    try {
      if (mode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({
          email: email.trim(),
          password
        });
        if (error) throw error;
        navigate('/');
      } else if (mode === 'register') {
        if (!artistName.trim()) throw new Error('يرجى إدخال الاسم الفني');
        const { error } = await supabase.auth.signUp({
          email: email.trim(),
          password,
          options: {
            data: {
              full_name: artistName.trim(),
              artist_name: artistName.trim()
            }
          }
        });
        if (error) throw error;
        setMessage('تم إنشاء الحساب بنجاح! تحقق من بريدك الإلكتروني لتأكيد الحساب أو سجّل الدخول.');
      } else if (mode === 'reset') {
        const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
          redirectTo: `${window.location.origin}/auth`
        });
        if (error) throw error;
        setMessage('تم إرسال رابط استعادة كلمة المرور إلى بريدك الإلكتروني.');
      }
    } catch (err) {
      setErrorMsg(err.message || 'حدث خطأ أثناء المصادقة');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="auth-page-wrapper">
      <div className="auth-card">
        <div className="auth-logo-top">
          <Logo size="lg" />
        </div>

        <div className="auth-tabs">
          <button
            type="button"
            className={mode === 'login' ? 'active' : ''}
            onClick={() => { setMode('login'); setErrorMsg(''); setMessage(''); }}
          >
            تسجيل الدخول
          </button>
          <button
            type="button"
            className={mode === 'register' ? 'active' : ''}
            onClick={() => { setMode('register'); setErrorMsg(''); setMessage(''); }}
          >
            إنشاء حساب فنان
          </button>
        </div>

        {errorMsg && <div className="alert-banner error mb-3">{errorMsg}</div>}
        {message && <div className="alert-banner info mb-3">{message}</div>}

        <form onSubmit={handleSubmit}>
          {mode === 'register' && (
            <div className="form-group">
              <label>الاسم الفني / اسم الرسام *</label>
              <div className="input-with-icon">
                <User size={17} />
                <input
                  type="text"
                  required
                  value={artistName}
                  onChange={(e) => setArtistName(e.target.value)}
                  placeholder="الاسم الذي سيظهر في المعرض"
                />
              </div>
            </div>
          )}

          <div className="form-group">
            <label>البريد الإلكتروني *</label>
            <div className="input-with-icon">
              <Mail size={17} />
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="artist@example.com"
              />
            </div>
          </div>

          {mode !== 'reset' && (
            <div className="form-group">
              <label>كلمة المرور *</label>
              <div className="input-with-icon">
                <Lock size={17} />
                <input
                  type="password"
                  required
                  minLength={6}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                />
              </div>
            </div>
          )}

          <button type="submit" className="btn btn-gold w-full btn-lg mt-2" disabled={loading}>
            {loading
              ? 'جاري التنفيذ...'
              : mode === 'login'
              ? 'دخول للمنصة'
              : mode === 'register'
              ? 'إنشاء الحساب'
              : 'إرسال رابط الاستعادة'}
          </button>
        </form>

        <div className="auth-footer-links">
          {mode !== 'reset' ? (
            <button type="button" className="link-btn" onClick={() => setMode('reset')}>
              <KeyRound size={14} /> نسيت كلمة المرور؟
            </button>
          ) : (
            <button type="button" className="link-btn" onClick={() => setMode('login')}>
              العودة لتسجيل الدخول
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
