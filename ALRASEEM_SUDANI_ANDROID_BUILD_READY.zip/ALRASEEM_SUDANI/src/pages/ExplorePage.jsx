import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, SlidersHorizontal } from 'lucide-react';
import { supabase } from '../supabase';
import { useAuth } from '../context/AuthContext';
import { ART_CATEGORIES } from '../i18n/translations';
import ArtworkCard from '../components/ArtworkCard';
import LightboxModal from '../components/LightboxModal';

export default function ExplorePage() {
  const { user, lang } = useAuth();
  const [searchParams, setSearchParams] = useSearchParams();

  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [category, setCategory] = useState(searchParams.get('cat') || 'all');
  const [sortBy, setSortBy] = useState('newest');
  const [artworks, setArtworks] = useState([]);
  const [userLikes, setUserLikes] = useState(new Set());
  const [userFavorites, setUserFavorites] = useState(new Set());
  const [lightboxArt, setLightboxArt] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchArtworks();
  }, [category, sortBy, user]);

  const fetchArtworks = async (customQuery = query) => {
    setLoading(true);
    try {
      let req = supabase.from('artworks').select('*').eq('status', 'approved');

      if (category !== 'all') {
        req = req.eq('category', category);
      }

      if (customQuery.trim()) {
        const term = `%${customQuery.trim()}%`;
        req = req.or(`title.ilike.${term},artist_name.ilike.${term},description.ilike.${term}`);
      }

      if (sortBy === 'popular') {
        req = req.order('likes_count', { ascending: false });
      } else {
        req = req.order('created_at', { ascending: false });
      }

      const { data } = await req;
      setArtworks(data || []);

      if (user) {
        const [{ data: likesRows }, { data: favRows }] = await Promise.all([
          supabase.from('likes').select('artwork_id').eq('user_id', user.id),
          supabase.from('favorites').select('artwork_id').eq('user_id', user.id)
        ]);
        setUserLikes(new Set((likesRows || []).map((r) => r.artwork_id)));
        setUserFavorites(new Set((favRows || []).map((r) => r.artwork_id)));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    setSearchParams({ q: query, cat: category });
    fetchArtworks(query);
  };

  return (
    <div className="container page-wrapper">
      <div className="page-header">
        <h1>معرض الأعمال الفنية المعتمدة</h1>
        <p className="text-muted">تصفح إبداعات الرسامين السودانيين من مختلف المدارس والأساليب الفنية</p>
      </div>

      {/* شريط البحث والتصفية */}
      <div className="filter-panel">
        <form onSubmit={handleSearch} className="search-bar-inline">
          <Search size={18} />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحث باسم اللوحة أو اسم الفنان..."
          />
          <button type="submit" className="btn btn-gold btn-sm">
            بحث
          </button>
        </form>

        <div className="sort-box">
          <SlidersHorizontal size={16} />
          <select value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
            <option value="newest">الأحدث نشراً</option>
            <option value="popular">الأكثر إعجاباً</option>
          </select>
        </div>
      </div>

      <div className="categories-bar mb-4">
        {ART_CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            type="button"
            className={`category-chip ${category === cat.id ? 'active' : ''}`}
            onClick={() => setCategory(cat.id)}
          >
            {lang === 'ar' ? cat.labelAr : cat.labelEn}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="loading-grid">
          {[1, 2, 3, 4, 5, 6].map((n) => (
            <div key={n} className="skeleton-card" />
          ))}
        </div>
      ) : artworks.length === 0 ? (
        <div className="empty-state-box">
          <p>لا توجد نتائج مطابقة لبحثك حالياً.</p>
        </div>
      ) : (
        <div className="artworks-grid">
          {artworks.map((art) => (
            <ArtworkCard
              key={art.id}
              artwork={art}
              isLiked={userLikes.has(art.id)}
              isFavorited={userFavorites.has(art.id)}
              onToggleLike={(id, liked) => {
                setUserLikes((prev) => {
                  const s = new Set(prev);
                  liked ? s.add(id) : s.delete(id);
                  return s;
                });
                setArtworks((list) =>
                  list.map((a) =>
                    a.id === id ? { ...a, likes_count: Math.max((a.likes_count || 0) + (liked ? 1 : -1), 0) } : a
                  )
                );
              }}
              onToggleFavorite={(id, fav) => {
                setUserFavorites((prev) => {
                  const s = new Set(prev);
                  fav ? s.add(id) : s.delete(id);
                  return s;
                });
              }}
              onOpenLightbox={setLightboxArt}
            />
          ))}
        </div>
      )}

      <LightboxModal artwork={lightboxArt} onClose={() => setLightboxArt(null)} />
    </div>
  );
}
