import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Palette, Award, Flame, Compass, PlusCircle, ArrowLeft } from 'lucide-react';
import { supabase } from '../supabase';
import { useAuth } from '../context/AuthContext';
import { ART_CATEGORIES } from '../i18n/translations';
import ArtworkCard from '../components/ArtworkCard';
import LightboxModal from '../components/LightboxModal';

export default function HomePage() {
  const { user, t, lang } = useAuth();
  const navigate = useNavigate();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [latestArtworks, setLatestArtworks] = useState([]);
  const [mostLikedArtworks, setMostLikedArtworks] = useState([]);
  const [featuredArtists, setFeaturedArtists] = useState([]);
  const [userLikes, setUserLikes] = useState(new Set());
  const [userFavorites, setUserFavorites] = useState(new Set());
  const [lightboxArt, setLightboxArt] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadHomeData();
  }, [selectedCategory, user]);

  const loadHomeData = async () => {
    setLoading(true);
    try {
      // 1. أحدث الرسومات المعتمدة فقط (approved)
      let latestQuery = supabase
        .from('artworks')
        .select('*')
        .eq('status', 'approved')
        .order('created_at', { ascending: false })
        .limit(8);

      if (selectedCategory !== 'all') {
        latestQuery = latestQuery.eq('category', selectedCategory);
      }

      const { data: latestData } = await latestQuery;
      setLatestArtworks(latestData || []);

      // 2. الأعمال الأكثر إعجاباً (approved)
      const { data: topLikedData } = await supabase
        .from('artworks')
        .select('*')
        .eq('status', 'approved')
        .order('likes_count', { ascending: false })
        .limit(4);

      setMostLikedArtworks(topLikedData || []);

      // 3. الفنانون المميزون
      const { data: artistsData } = await supabase
        .from('profiles')
        .select('*')
        .order('is_featured', { ascending: false })
        .order('created_at', { ascending: false })
        .limit(6);

      setFeaturedArtists(artistsData || []);

      // 4. إعجابات ومفضلة المستخدم الحالي
      if (user) {
        const [{ data: likesRows }, { data: favRows }] = await Promise.all([
          supabase.from('likes').select('artwork_id').eq('user_id', user.id),
          supabase.from('favorites').select('artwork_id').eq('user_id', user.id)
        ]);
        setUserLikes(new Set((likesRows || []).map((r) => r.artwork_id)));
        setUserFavorites(new Set((favRows || []).map((r) => r.artwork_id)));
      } else {
        setUserLikes(new Set());
        setUserFavorites(new Set());
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    navigate(`/explore?q=${encodeURIComponent(searchQuery.trim())}`);
  };

  const handleLikeUpdate = (artworkId, liked) => {
    setUserLikes((prev) => {
      const next = new Set(prev);
      liked ? next.add(artworkId) : next.delete(artworkId);
      return next;
    });
    const updater = (list) =>
      list.map((item) =>
        item.id === artworkId
          ? { ...item, likes_count: Math.max((item.likes_count || 0) + (liked ? 1 : -1), 0) }
          : item
      );
    setLatestArtworks(updater);
    setMostLikedArtworks(updater);
  };

  const handleFavUpdate = (artworkId, favored) => {
    setUserFavorites((prev) => {
      const next = new Set(prev);
      favored ? next.add(artworkId) : next.delete(artworkId);
      return next;
    });
  };

  return (
    <div className="home-page">
      {/* الواجهة الترحيبية الفاخرة (Hero Section) */}
      <section className="hero-section">
        <div className="hero-glow" />
        <div className="container hero-content">
          <div className="hero-badge">
            <Palette size={16} />
            <span>{t.heroBadge}</span>
          </div>

          <h1 className="hero-title">{t.heroTitle}</h1>
          <p className="hero-subtitle">{t.heroDesc}</p>

          {/* مربع البحث الرئيسي */}
          <form onSubmit={handleSearchSubmit} className="hero-search-form">
            <Search size={20} className="search-icon" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={t.searchPlaceholder}
            />
            <button type="submit" className="btn btn-gold">
              بحث
            </button>
          </form>

          {/* أزرار الدعوة لاتخاذ إجراء */}
          <div className="hero-cta-group">
            <Link to={user ? '/publish' : '/auth?mode=register'} className="btn btn-gold btn-lg">
              <PlusCircle size={20} />
              <span>{user ? t.publishArt : t.joinAsArtist}</span>
            </Link>
            <Link to="/explore" className="btn btn-outline btn-lg">
              <Compass size={20} />
              <span>{t.exploreNow}</span>
            </Link>
          </div>
        </div>
      </section>

      {/* قسم التصنيفات الفنية */}
      <section className="section container">
        <div className="section-header">
          <h2>{t.categoriesTitle}</h2>
        </div>
        <div className="categories-bar">
          {ART_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              type="button"
              className={`category-chip ${selectedCategory === cat.id ? 'active' : ''}`}
              onClick={() => setSelectedCategory(cat.id)}
            >
              {lang === 'ar' ? cat.labelAr : cat.labelEn}
            </button>
          ))}
        </div>
      </section>

      {/* قسم أحدث الرسومات المعتمدة */}
      <section className="section container">
        <div className="section-header">
          <div className="section-title-group">
            <Palette size={22} className="gold-text" />
            <h2>{t.latestArtworks}</h2>
          </div>
          <Link to="/explore" className="view-all-link">
            <span>عرض الكل</span>
            <ArrowLeft size={16} />
          </Link>
        </div>

        {loading ? (
          <div className="loading-grid">
            {[1, 2, 3, 4].map((n) => (
              <div key={n} className="skeleton-card" />
            ))}
          </div>
        ) : latestArtworks.length === 0 ? (
          <div className="empty-state-box">
            <p>لا توجد أعمال فنية معتمدة في هذا التصنيف حالياً. كن أول من يشارك إبداعه!</p>
            <Link to={user ? '/publish' : '/auth'} className="btn btn-gold mt-3">
              نشر عمل فني
            </Link>
          </div>
        ) : (
          <div className="artworks-grid">
            {latestArtworks.map((art) => (
              <ArtworkCard
                key={art.id}
                artwork={art}
                isLiked={userLikes.has(art.id)}
                isFavorited={userFavorites.has(art.id)}
                onToggleLike={handleLikeUpdate}
                onToggleFavorite={handleFavUpdate}
                onOpenLightbox={setLightboxArt}
              />
            ))}
          </div>
        )}
      </section>

      {/* قسم الأعمال الأكثر إعجاباً */}
      {mostLikedArtworks.length > 0 && (
        <section className="section container">
          <div className="section-header">
            <div className="section-title-group">
              <Flame size={22} className="gold-text" />
              <h2>{t.mostLiked}</h2>
            </div>
          </div>

          <div className="artworks-grid">
            {mostLikedArtworks.map((art) => (
              <ArtworkCard
                key={art.id}
                artwork={art}
                isLiked={userLikes.has(art.id)}
                isFavorited={userFavorites.has(art.id)}
                onToggleLike={handleLikeUpdate}
                onToggleFavorite={handleFavUpdate}
                onOpenLightbox={setLightboxArt}
              />
            ))}
          </div>
        </section>
      )}

      {/* قسم الفنانين المميزين */}
      <section className="section container">
        <div className="section-header">
          <div className="section-title-group">
            <Award size={22} className="gold-text" />
            <h2>{t.featuredArtists}</h2>
          </div>
          <Link to="/artists" className="view-all-link">
            <span>جميع الفنانين</span>
            <ArrowLeft size={16} />
          </Link>
        </div>

        {featuredArtists.length === 0 ? (
          <div className="empty-state-box">
            <p>قائمة الفنانين المميزين ستظهر هنا فور انضمام الرسامين.</p>
          </div>
        ) : (
          <div className="artists-grid">
            {featuredArtists.map((artist) => (
              <Link key={artist.id} to={`/artist/${artist.id}`} className="artist-card">
                {artist.avatar_url ? (
                  <img src={artist.avatar_url} alt={artist.artist_name} className="artist-avatar-lg" />
                ) : (
                  <div className="artist-avatar-lg avatar-fallback">
                    {(artist.artist_name || artist.full_name || 'ف')[0]}
                  </div>
                )}
                <h3>{artist.artist_name || artist.full_name || 'فنان سوداني'}</h3>
                <span className="artist-specialty">{artist.specialty || 'فنان تشكيلي'}</span>
                <p className="artist-bio-snippet">
                  {artist.bio || 'عضو مبدع في منصة الرسيم السوداني للفنون البصرية.'}
                </p>
              </Link>
            ))}
          </div>
        )}
      </section>

      <LightboxModal artwork={lightboxArt} onClose={() => setLightboxArt(null)} />
    </div>
  );
}
