-- ============================================================================
-- مشروع الرسيم السوداني | ALRASEEM SUDANI
-- سكربت قاعدة البيانات الآمن (يحافظ على البيانات والجداول الموجودة ولا يحذف شيئاً)
-- ============================================================================

-- تفعيل الإضافات المطلوبة
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. جدول الملفات الشخصية (profiles) - تحديث آمن للأعمدة الناقصة فقط
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT,
  artist_name TEXT,
  bio TEXT,
  avatar_url TEXT,
  city TEXT,
  specialty TEXT,
  is_featured BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS artist_name TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS bio TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS avatar_url TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS city TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS specialty TEXT;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS is_featured BOOLEAN DEFAULT false;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- 2. جدول المشرفين (admin_users)
CREATE TABLE IF NOT EXISTS public.admin_users (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  role TEXT DEFAULT 'admin' CHECK (role IN ('admin', 'super_admin', 'moderator')),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- دالة مساعدة آمنة للتحقق من صلاحية المدير
CREATE OR REPLACE FUNCTION public.is_admin(uid UUID DEFAULT auth.uid())
RETURNS BOOLEAN
LANGUAGE sql
SECURITY DEFINER
SET search_path = public
STABLE
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.admin_users WHERE user_id = uid
  );
$$;

-- 3. جدول الأعمال الفنية (artworks) - تحديث آمن
CREATE TABLE IF NOT EXISTS public.artworks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  description TEXT,
  artist_name TEXT,
  category TEXT DEFAULT 'رسم تشكيلي',
  image_url TEXT NOT NULL,
  status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  rejection_reason TEXT,
  likes_count INTEGER DEFAULT 0,
  views_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.artworks ADD COLUMN IF NOT EXISTS artist_name TEXT;
ALTER TABLE public.artworks ADD COLUMN IF NOT EXISTS category TEXT DEFAULT 'رسم تشكيلي';
ALTER TABLE public.artworks ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'pending';
ALTER TABLE public.artworks ADD COLUMN IF NOT EXISTS rejection_reason TEXT;
ALTER TABLE public.artworks ADD COLUMN IF NOT EXISTS likes_count INTEGER DEFAULT 0;
ALTER TABLE public.artworks ADD COLUMN IF NOT EXISTS views_count INTEGER DEFAULT 0;
ALTER TABLE public.artworks ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW();

-- فرض حالة pending عند الإدراج من غير المدير لضمان المراجعة الإجبارية
CREATE OR REPLACE FUNCTION public.enforce_pending_artwork()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NOT public.is_admin(auth.uid()) THEN
    NEW.status := 'pending';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_enforce_pending_artwork ON public.artworks;
CREATE TRIGGER trg_enforce_pending_artwork
BEFORE INSERT ON public.artworks
FOR EACH ROW EXECUTE FUNCTION public.enforce_pending_artwork();

-- منع المستخدم العادي من تغيير حالة العمل إلى approved بنفسه
CREATE OR REPLACE FUNCTION public.protect_artwork_status_update()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF NOT public.is_admin(auth.uid()) THEN
    IF NEW.status IS DISTINCT FROM OLD.status THEN
      RAISE EXCEPTION 'غير مصرح بتغيير حالة نشر العمل الفني إلا بواسطة الإدارة';
    END IF;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_protect_artwork_status_update ON public.artworks;
CREATE TRIGGER trg_protect_artwork_status_update
BEFORE UPDATE ON public.artworks
FOR EACH ROW EXECUTE FUNCTION public.protect_artwork_status_update();

-- 4. جدول الإعجابات (likes) مع منع التكرار
CREATE TABLE IF NOT EXISTS public.likes (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  artwork_id UUID NOT NULL REFERENCES public.artworks(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(artwork_id, user_id)
);

-- تحديث عداد الإعجابات تلقائياً
CREATE OR REPLACE FUNCTION public.sync_artwork_likes_count()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE public.artworks SET likes_count = COALESCE(likes_count, 0) + 1 WHERE id = NEW.artwork_id;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    UPDATE public.artworks SET likes_count = GREATEST(COALESCE(likes_count, 0) - 1, 0) WHERE id = OLD.artwork_id;
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trg_sync_artwork_likes ON public.likes;
CREATE TRIGGER trg_sync_artwork_likes
AFTER INSERT OR DELETE ON public.likes
FOR EACH ROW EXECUTE FUNCTION public.sync_artwork_likes_count();

-- 5. جدول التعليقات (comments) - يدعم النص والصوت
CREATE TABLE IF NOT EXISTS public.comments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  artwork_id UUID NOT NULL REFERENCES public.artworks(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  content TEXT,
  audio_url TEXT,
  audio_duration INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE public.comments ADD COLUMN IF NOT EXISTS audio_url TEXT;
ALTER TABLE public.comments ADD COLUMN IF NOT EXISTS audio_duration INTEGER DEFAULT 0;

-- 6. جدول المتابعة (follows)
CREATE TABLE IF NOT EXISTS public.follows (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  follower_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  following_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(follower_id, following_id),
  CHECK (follower_id <> following_id)
);

-- 7. جدول المفضلة (favorites)
CREATE TABLE IF NOT EXISTS public.favorites (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  artwork_id UUID NOT NULL REFERENCES public.artworks(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(user_id, artwork_id)
);

-- 8. جدول الإشعارات (notifications)
CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  actor_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  type TEXT NOT NULL CHECK (type IN ('like', 'comment', 'follow', 'artwork_approved', 'artwork_rejected', 'contest_win', 'system')),
  title TEXT NOT NULL,
  message TEXT,
  link TEXT,
  is_read BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 9. جدول المسابقات الفنية (contests)
CREATE TABLE IF NOT EXISTS public.contests (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  rules TEXT,
  prize_details TEXT,
  certificate_template_url TEXT,
  banner_url TEXT,
  start_date TIMESTAMPTZ NOT NULL,
  end_date TIMESTAMPTZ NOT NULL,
  status TEXT DEFAULT 'active' CHECK (status IN ('upcoming', 'active', 'judging', 'completed')),
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 10. جدول مشاركات المسابقات (contest_entries)
CREATE TABLE IF NOT EXISTS public.contest_entries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  contest_id UUID NOT NULL REFERENCES public.contests(id) ON DELETE CASCADE,
  artwork_id UUID NOT NULL REFERENCES public.artworks(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  is_winner BOOLEAN DEFAULT false,
  winner_rank INTEGER,
  certificate_url TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  UNIQUE(contest_id, user_id)
);

-- 11. جدول المعارض الافتراضية (exhibitions)
CREATE TABLE IF NOT EXISTS public.exhibitions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  theme TEXT,
  description TEXT NOT NULL,
  curator_name TEXT DEFAULT 'إدارة الرسيم السوداني',
  cover_url TEXT,
  start_date TIMESTAMPTZ DEFAULT NOW(),
  end_date TIMESTAMPTZ,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS public.exhibition_artworks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  exhibition_id UUID NOT NULL REFERENCES public.exhibitions(id) ON DELETE CASCADE,
  artwork_id UUID NOT NULL REFERENCES public.artworks(id) ON DELETE CASCADE,
  display_order INTEGER DEFAULT 0,
  UNIQUE(exhibition_id, artwork_id)
);

-- 12. جدول البلاغات (reports)
CREATE TABLE IF NOT EXISTS public.reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reporter_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  artwork_id UUID REFERENCES public.artworks(id) ON DELETE CASCADE,
  comment_id UUID REFERENCES public.comments(id) ON DELETE CASCADE,
  reason TEXT NOT NULL,
  details TEXT,
  status TEXT DEFAULT 'open' CHECK (status IN ('open', 'resolved', 'dismissed')),
  admin_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================================
-- إنشاء ملف شخصي تلقائياً عند تسجيل مستخدم جديد
-- ============================================================================
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name, artist_name, avatar_url)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'artist_name', NEW.raw_user_meta_data->>'full_name', split_part(NEW.email, '@', 1)),
    NEW.raw_user_meta_data->>'avatar_url'
  )
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
AFTER INSERT ON auth.users
FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- ============================================================================
-- تفعيل سياسات أمان الصفوف (Row Level Security - RLS) على جميع الجداول
-- ============================================================================
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.artworks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.likes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.comments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.follows ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contests ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.contest_entries ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exhibitions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.exhibition_artworks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.reports ENABLE ROW LEVEL SECURITY;

-- سياسات profiles
DROP POLICY IF EXISTS "Public profiles are viewable by everyone" ON public.profiles;
CREATE POLICY "Public profiles are viewable by everyone" ON public.profiles FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
CREATE POLICY "Users can update own profile" ON public.profiles FOR UPDATE USING (auth.uid() = id OR public.is_admin());

DROP POLICY IF EXISTS "Users can insert own profile" ON public.profiles;
CREATE POLICY "Users can insert own profile" ON public.profiles FOR INSERT WITH CHECK (auth.uid() = id);

-- سياسات admin_users
DROP POLICY IF EXISTS "Admins can view admin list" ON public.admin_users;
CREATE POLICY "Admins can view admin list" ON public.admin_users FOR SELECT USING (auth.uid() = user_id OR public.is_admin());

-- سياسات artworks (المعتمدة للعامة + المعلقة لصاحبها أو للمدير فقط)
DROP POLICY IF EXISTS "Approved artworks are viewable by everyone" ON public.artworks;
CREATE POLICY "Approved artworks are viewable by everyone" ON public.artworks
FOR SELECT USING (status = 'approved' OR auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "Authenticated users can insert artworks" ON public.artworks;
CREATE POLICY "Authenticated users can insert artworks" ON public.artworks
FOR INSERT WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Owners and admins can update artworks" ON public.artworks;
CREATE POLICY "Owners and admins can update artworks" ON public.artworks
FOR UPDATE USING (auth.uid() = user_id OR public.is_admin());

DROP POLICY IF EXISTS "Owners and admins can delete artworks" ON public.artworks;
CREATE POLICY "Owners and admins can delete artworks" ON public.artworks
FOR DELETE USING (auth.uid() = user_id OR public.is_admin());

-- سياسات likes
DROP POLICY IF EXISTS "Likes are viewable by everyone" ON public.likes;
CREATE POLICY "Likes are viewable by everyone" ON public.likes FOR SELECT USING (true);

DROP POLICY IF EXISTS "Authenticated users can like" ON public.likes;
CREATE POLICY "Authenticated users can like" ON public.likes FOR INSERT WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users can remove own like" ON public.likes;
CREATE POLICY "Users can remove own like" ON public.likes FOR DELETE USING (auth.uid() = user_id);

-- سياسات comments
DROP POLICY IF EXISTS "Comments are viewable by everyone" ON public.comments;
CREATE POLICY "Comments are viewable by everyone" ON public.comments FOR SELECT USING (true);

DROP POLICY IF EXISTS "Authenticated users can comment" ON public.comments;
CREATE POLICY "Authenticated users can comment" ON public.comments FOR INSERT WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Owners and admins can delete comments" ON public.comments;
CREATE POLICY "Owners and admins can delete comments" ON public.comments FOR DELETE USING (auth.uid() = user_id OR public.is_admin());

-- سياسات follows
DROP POLICY IF EXISTS "Follows are viewable by everyone" ON public.follows;
CREATE POLICY "Follows are viewable by everyone" ON public.follows FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users can follow" ON public.follows;
CREATE POLICY "Users can follow" ON public.follows FOR INSERT WITH CHECK (auth.uid() = follower_id);

DROP POLICY IF EXISTS "Users can unfollow" ON public.follows;
CREATE POLICY "Users can unfollow" ON public.follows FOR DELETE USING (auth.uid() = follower_id);

-- سياسات favorites
DROP POLICY IF EXISTS "Users view own favorites" ON public.favorites;
CREATE POLICY "Users view own favorites" ON public.favorites FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users add own favorites" ON public.favorites;
CREATE POLICY "Users add own favorites" ON public.favorites FOR INSERT WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Users delete own favorites" ON public.favorites;
CREATE POLICY "Users delete own favorites" ON public.favorites FOR DELETE USING (auth.uid() = user_id);

-- سياسات notifications
DROP POLICY IF EXISTS "Users view own notifications" ON public.notifications;
CREATE POLICY "Users view own notifications" ON public.notifications FOR SELECT USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Authenticated users can create notifications" ON public.notifications;
CREATE POLICY "Authenticated users can create notifications" ON public.notifications FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users update own notifications" ON public.notifications;
CREATE POLICY "Users update own notifications" ON public.notifications FOR UPDATE USING (auth.uid() = user_id);

-- سياسات contests & contest_entries
DROP POLICY IF EXISTS "Contests viewable by all" ON public.contests;
CREATE POLICY "Contests viewable by all" ON public.contests FOR SELECT USING (true);

DROP POLICY IF EXISTS "Only admins manage contests" ON public.contests;
CREATE POLICY "Only admins manage contests" ON public.contests FOR ALL USING (public.is_admin());

DROP POLICY IF EXISTS "Contest entries viewable by all" ON public.contest_entries;
CREATE POLICY "Contest entries viewable by all" ON public.contest_entries FOR SELECT USING (true);

DROP POLICY IF EXISTS "Users can submit contest entry" ON public.contest_entries;
CREATE POLICY "Users can submit contest entry" ON public.contest_entries FOR INSERT WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Admins manage contest entries" ON public.contest_entries;
CREATE POLICY "Admins manage contest entries" ON public.contest_entries FOR UPDATE USING (public.is_admin());

-- سياسات exhibitions
DROP POLICY IF EXISTS "Exhibitions viewable by all" ON public.exhibitions;
CREATE POLICY "Exhibitions viewable by all" ON public.exhibitions FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admins manage exhibitions" ON public.exhibitions;
CREATE POLICY "Admins manage exhibitions" ON public.exhibitions FOR ALL USING (public.is_admin());

DROP POLICY IF EXISTS "Exhibition artworks viewable by all" ON public.exhibition_artworks;
CREATE POLICY "Exhibition artworks viewable by all" ON public.exhibition_artworks FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admins manage exhibition artworks" ON public.exhibition_artworks;
CREATE POLICY "Admins manage exhibition artworks" ON public.exhibition_artworks FOR ALL USING (public.is_admin());

-- سياسات reports
DROP POLICY IF EXISTS "Users can create reports" ON public.reports;
CREATE POLICY "Users can create reports" ON public.reports FOR INSERT WITH CHECK (auth.uid() = reporter_id);

DROP POLICY IF EXISTS "Admins view and manage reports" ON public.reports;
CREATE POLICY "Admins view and manage reports" ON public.reports FOR SELECT USING (public.is_admin() OR auth.uid() = reporter_id);

DROP POLICY IF EXISTS "Admins update reports" ON public.reports;
CREATE POLICY "Admins update reports" ON public.reports FOR UPDATE USING (public.is_admin());

-- ============================================================================
-- سياسات التخزين السحابي لحاوية (artworks)
-- ============================================================================
INSERT INTO storage.buckets (id, name, public)
VALUES ('artworks', 'artworks', true)
ON CONFLICT (id) DO NOTHING;

DROP POLICY IF EXISTS "Public read access for artworks bucket" ON storage.objects;
CREATE POLICY "Public read access for artworks bucket"
ON storage.objects FOR SELECT
USING (bucket_id = 'artworks');

DROP POLICY IF EXISTS "Authenticated users can upload to artworks bucket" ON storage.objects;
CREATE POLICY "Authenticated users can upload to artworks bucket"
ON storage.objects FOR INSERT
WITH CHECK (
  bucket_id = 'artworks'
  AND auth.role() = 'authenticated'
  AND (storage.foldername(name))[1] = auth.uid()::text
);

DROP POLICY IF EXISTS "Users can delete own files in artworks bucket" ON storage.objects;
CREATE POLICY "Users can delete own files in artworks bucket"
ON storage.objects FOR DELETE
USING (
  bucket_id = 'artworks'
  AND ((storage.foldername(name))[1] = auth.uid()::text OR public.is_admin())
);
