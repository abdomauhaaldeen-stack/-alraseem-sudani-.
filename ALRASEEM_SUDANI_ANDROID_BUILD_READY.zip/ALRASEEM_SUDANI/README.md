# الرسيم السوداني | ALRASEEM SUDANI

منصة فنية سودانية متكاملة (موقع إلكتروني متجاوب + تطبيق Android عبر Capacitor + لوحة تحكم إدارية + قاعدة بيانات سحابية مشتركة عبر Supabase).

---

## 1. هيكل المشروع

```text
ALRASEEM_SUDANI/
├── index.html                  # الصفحة الرئيسية بواجهة عربية RTL
├── package.json                # الحزم والاعتماديات (React, Vite, Supabase, Capacitor, Lucide)
├── vite.config.js              # إعدادات البناء والتطوير
├── capacitor.config.json       # إعدادات تطبيق Android (com.alraseem.sudani)
├── .env                        # بيانات الربط مع مشروع Supabase
├── .env.example                # نموذج متغيرات البيئة
├── supabase/
│   └── schema.sql              # سكربت تحديث الجداول وسياسات الأمان RLS دون حذف البيانات
└── src/
    ├── main.jsx                # نقطة انطلاق التطبيق
    ├── App.jsx                 # التوجيه والمسارات
    ├── supabase.js             # عميل Supabase ودوال الرفع الآمن للصور والصوت
    ├── style.css               # الهوية البصرية (عاجي + طيني/نحاسي + RTL بطابع معرض فني)
    ├── i18n/
    │   └── translations.js     # دعم العربية والتهيئة للإنجليزية
    ├── context/
    │   └── AuthContext.jsx     # إدارة الجلسة وصلاحيات المدير من قاعدة البيانات
    ├── components/
    │   ├── Logo.jsx            # الشعار المخصص للمنصة
    │   ├── Navbar.jsx          # شريط التنقل المتجاوب
    │   ├── Footer.jsx          # تذييل المنصة
    │   ├── ArtworkCard.jsx     # بطاقة العرض الفني والتفاعل
    │   ├── LightboxModal.jsx   # عارض اللوحات بالحجم الكامل
    │   └── VoiceRecorder.jsx   # مسجل التعليقات الصوتية
    └── pages/
        ├── HomePage.jsx        # الواجهة الرئيسية
        ├── ExplorePage.jsx     # المعرض والبحث والتصفية
        ├── ArtworkDetailPage.jsx # تفاصيل اللوحة والتعليقات النصية والصوتية
        ├── PublishArtworkPage.jsx # رفع عمل فني جديد (يُرسل بحالة Pending)
        ├── ArtistProfilePage.jsx # الملف الشخصي للفنان وتعديل البيانات
        ├── ArtistsListPage.jsx # دليل الفنانين
        ├── ContestsPage.jsx    # المسابقات والجوائز والشهادات
        ├── ExhibitionsPage.jsx # المعارض الفنية الافتراضية
        ├── FavoritesPage.jsx   # المفضلة
        ├── NotificationsPage.jsx # إشعارات التفاعل
        ├── AuthPage.jsx        # تسجيل الدخول وإنشاء الحساب واستعادة كلمة المرور
        └── admin/
            └── AdminDashboard.jsx # لوحة تحكم المدير المستقلة
```

---

## 2. خطوات إعداد قاعدة البيانات (Supabase)

1. افتح لوحة تحكم مشروعك في Supabase:
   `https://zzvhrhnnosptqmsygzpp.supabase.co`
2. انتقل إلى **SQL Editor**، وانسخ محتوى الملف `supabase/schema.sql` بالكامل ثم اضغط **Run**.
   - هذا السكربت مصمم بعناية باستخدام `CREATE TABLE IF NOT EXISTS` و `ADD COLUMN IF NOT EXISTS` بحيث **يحافظ على جميع الجداول والبيانات الموجودة لديك مسبقاً** ويُفعّل سياسات الأمان **RLS**.
3. **تعيين حسابك كمدير (Admin):**
   - بعد إنشاء حسابك في المنصة، انسخ `User UID` الخاص بك من قسم **Authentication -> Users** في Supabase.
   - نفّذ الأمر التالي في SQL Editor لمنح نفسك صلاحية المدير في قاعدة البيانات:
     ```sql
     INSERT INTO public.admin_users (user_id, role)
     VALUES ('ضع-هنا-معرف-المستخدم-UUID', 'super_admin')
     ON CONFLICT (user_id) DO NOTHING;
     ```

---

## 3. تشغيل الموقع محلياً (Web)

تأكد من تثبيت **Node.js (الإصدار 18 أو أحدث)** على جهازك، ثم نفّذ الأوامر التالية داخل مجلد المشروع:

```bash
npm install
npm run dev
```

سيعمل الموقع على الرابط: `http://localhost:5173`

---

## 4. تحويل المشروع إلى تطبيق Android وبناء APK

1. قم ببناء نسخة الإنتاج للموقع:
   ```bash
   npm run build
   ```
2. أضف منصة Android عبر Capacitor (تُنفّذ مرة واحدة فقط):
   ```bash
   npx cap add android
   ```
3. زامن ملفات الويب مع مشروع Android:
   ```bash
   npx cap sync android
   ```
4. افتح المشروع في **Android Studio**:
   ```bash
   npx cap open android
   ```
5. من داخل Android Studio:
   - تأكد من إضافة أذونات الكاميرا والملفات والميكروفون في `android/app/src/main/AndroidManifest.xml` إذا لم تُضف تلقائياً:
     ```xml
     <uses-permission android:name="android.permission.INTERNET" />
     <uses-permission android:name="android.permission.CAMERA" />
     <uses-permission android:name="android.permission.RECORD_AUDIO" />
     <uses-permission android:name="android.permission.READ_MEDIA_IMAGES" />
     ```
   - اختر من القائمة العلوية: **Build > Build Bundle(s) / APK(s) > Build APK(s)** لإنتاج ملف التثبيت `app-debug.apk` أو توقيع نسخة الإنتاج `app-release.apk`.


## 5. الهوية البصرية الحالية
تم اعتماد اتجاه بصري تحريري مستوحى من صالات العرض والمتاحف: خلفيات عاجية دافئة، درجات طينية ونحاسية، عناوين عربية أنيقة، ومساحات عرض أكبر للأعمال الفنية. تم تجنب التوهجات والزخارف التقنية والبطاقات الزجاجية حتى تبدو المنصة كمعرض فني مستقل لا كواجهة ذكاء اصطناعي.


## 6. بناء APK سحابياً من الهاتف (GitHub Actions)

تمت إضافة سير عمل تلقائي في `.github/workflows/android-apk.yml` لبناء نسخة Android دون الحاجة إلى Android Studio على الهاتف.

1. ارفع مجلد المشروع إلى مستودع GitHub جديد باسم `alraseem-sudani`، واجعل الفرع الأساسي `main`.
2. من صفحة المستودع افتح **Settings → Secrets and variables → Actions → Variables** ثم أضف متغيرين (Repository variables):
   - `VITE_SUPABASE_URL` = رابط مشروع Supabase الموضح في ملف `.env.example`.
   - `VITE_SUPABASE_ANON_KEY` = مفتاح Supabase من ملف `.env.example` (مفتاح publishable/anon فقط، وليس service_role).
3. افتح تبويب **Actions**، واختر **Build Android APK**، ثم اضغط **Run workflow**.
4. بعد نجاح التشغيل، افتح نتيجة التشغيل ثم قسم **Artifacts** ونزّل `alraseem-sudani-debug-apk`.
5. فك ضغط الملف الذي تم تنزيله، ثم ثبّت `app-debug.apk` على هاتف Android.

ملاحظة: هذه الخطوات تُنشئ APK تجريبياً (debug). نشر التطبيق رسمياً على Google Play يحتاج لاحقاً إلى توقيع إصدار release ومفتاح keystore محفوظ بأمان.
